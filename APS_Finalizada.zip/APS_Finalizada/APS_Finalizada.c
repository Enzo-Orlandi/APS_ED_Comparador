//declara��o de bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
//declara��o de vairi�veis
int* array;
int tamanhoArray;
bool primeiraOpcao = true;
int opcao;
int primeiroMetodo;
int segundoMetodo;
int tamanhoBase;
int verificador;
clock_t tempo;
FILE *dados;
//fun��es
void menu(){//menu para sele��o de m�todos
    //if verifica se � a primeira ou segunda op�ao a ser escolhida para adpatar o texto
    if(primeiraOpcao){
        opcao = 1;
        primeiraOpcao = !primeiraOpcao;
    }
    else{
        opcao = 2;
        primeiraOpcao = !primeiraOpcao;
    }
    printf("Escolha o %do metodo de ordenacao\n", opcao);
    printf("1 - Insertion Sort\n");
    printf("2 - Selection Sort\n");
    printf("3 - Bubble Sort\n");
    printf("4 - Quick Sort\n");
    printf("5 - Merge Sort\n");
    printf("6 - Shell Sort\n");
    printf("0 - SAIR\n\n");
}

void menuDados(){//menu para a base de dados
    printf("Escolha o tamanho da base de dados\n");
    printf("1 - 1.000 Linhas\n");
    printf("2 - 5.000 Linhas\n");
    printf("3 - 10.000 Linhas\n");
    printf("4 - 50.000 Linhas\n");
    printf("5 - 100.000 Linhas\n");
    printf("6 - 500.000 Linhas\n");
    printf("0 - SAIR\n\n");
}

void carregarDados(){//transfere a base de dados para um array para ser manipulado sem afetar a base original
    for(int i = 0; i < tamanhoArray; i++){
        if(fscanf(dados, "%d", &verificador) != EOF){
            array[i] = verificador;
            // Para visualiza��o dos dados
            //printf("%d\n", array[i]);
        }
    }
    fclose(dados);// fecha a base de dados
}

void insercao (int vet[], int tam){//fun��o para o insertion sort - percorre um vetor de elementos da esquerda para a direita e � medida que avan�a vai ordenando os elementos � esquerda
    int i, j, x;
    for (i=2; i<=tam; i++){
        x = vet[i];
        j=i-1;
        vet[0] = x;
        while (x < vet[j]){
            vet[j+1] = vet[j];
            j--;
        }
        vet[j+1] = x;
    }
}

void selecao (int vet[], int tam){// fun��o para o selection sort - consiste em selecionar o menor item e colocar na primeira posi��o, selecionar o segundo menor item e colocar na segunda posi��o, segue estes passos at� que reste um �nico elemento
    int i, j, min, x;
    for (i=1; i<=tam-1; i++){
        min = i;
	for (j=i+1; j<=tam; j++){
            if (vet[j] < vet[min])
	        min = j;
	}
	x = vet[min];
	vet[min] = vet[i];
	vet[i] = x;
    }
}

void swap(int *a, int *b) {//fun��o para troca de elementos
    int t = *a;
    *a = *b;
    *b = t;
}

int partition(int array[], int low, int high) {//fun��o para encontrar o ponto de parti��o do array
    int pivot = array[high];//seleciona o ultimo elemento como pivo
    int i = (low - 1);//posicionamento do ponteiro do valor maior
    for (int j = low; j < high; j++) {//utiliza low como ponteiro do valor menor
        if (array[j] <= pivot) {
        i++;
        swap(&array[i], &array[j]);//troca dos elementos nos ponteiros
        }
    }
    swap(&array[i + 1], &array[high]);//troca dos elementos com o pivo
    return (i + 1);//retorna o valor da parti��o
}

void quickSort(int array[], int low, int high) {//fun��o do quick sort
    if (low < high) {//encontra o pivo e psiciona elementos menores a esquerda e maiores a direita
        int pi = partition(array, low, high);
        quickSort(array, low, pi - 1);//chamada recursiva para elementos a esquerda
        quickSort(array, pi + 1, high);//chamada recursiva para elementos a direita
    }
}
void bubbleSort(int array[], int size) {//fun��o do bubble sort
    for (int step = 0; step < size - 1; ++step) {//loop para acessar todos os termos do array
        int swapped = 0;//checa se est� pcprrendo trocas
        for (int i = 0; i < size - step - 1; ++i) {//loop para compara��o entre termos do array
            if (array[i] > array[i + 1]) {//> = ascendente/< = descentende
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
                swapped = 1;//trocas ocorrem se os termos n�o est� ona ordem selecionada
            }
        }
        if (swapped == 0) {// sem trocas significa que o array est� em ordem
            break;
        }
    }
}

void shellSort(int array[], int n) {//fun��o do shell sort
    for (int interval = n / 2; interval > 0; interval /= 2) {//arruma os elementos nos intervalos n/2, n/4, n/8 ... n/(2^x >=n)
        for (int i = interval; i < n; i += 1) {
            int temp = array[i];
            int j;
            for (j = i; j >= interval && array[j - interval] > temp; j -= interval) {
                array[j] = array[j - interval];
            }
            array[j] = temp;
        }
    }
}
// Merge two subarrays L and M into arr
void merge(int arr[], int p, int q, int r) {//junta os subarryas em um
    int n1 = q - p + 1;
    int n2 = r - q;
    int L[n1], M[n2];
    for (int i = 0; i < n1; i++)
        L[i] = arr[p + i];
    for (int j = 0; j < n2; j++)
        M[j] = arr[q + 1 + j];
    // guarda informa��es sobre os index dos subarrays e do array "juntado"
    int i, j, k;
    i = 0;
    j = 0;
    k = p;
    while (i < n1 && j < n2) {//at� que se chegue ao fim dos subarrays, pega os maiores elementos entre ambos ecoloca-os no local correto na primeira metade
        if (L[i] <= M[j]) {
        arr[k] = L[i];
        i++;
        }
        else {
            arr[k] = M[j];
            j++;
        }
        k++;
    }
    while (i < n1) {//quando chega no final do elementos, coloca os restantes na segunda metade do array
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = M[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int l, int r) {//divide o array em dois, arruma e junta eles
    if (l < r) {
        // m is the point where the array is divided into two subarrays
        int m = l + (r - l) / 2;//m � o ponto o array � dividido
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);//junta os arrays
    }
}

void executaMetodo(int escolha){
    //tamanhoArray = utiliza o tamamho alocado do array
    //tamanho array = utiliza a posi��o dentro do array
    switch(escolha){
        case 1:
            tempo = clock();
            insercao(array, tamanhoArray);
            tempo = clock() - tempo;
            printf("Tempo de ordenacao com Insertion Sort para %d dados foi de: %lf\n", tamanhoArray, ((double)tempo)/((CLOCKS_PER_SEC/1000)));
            break;
        case 2:
            tempo = clock();
            selecao(array, tamanhoArray);
            tempo = clock() - tempo;
            printf("Tempo de ordenacao com Selection Sort para %d dados foi de: %lf\n", tamanhoArray, ((double)tempo)/((CLOCKS_PER_SEC/1000)));
            break;
        case 3:
            tempo = clock();
            bubbleSort(array, tamanhoArray);
            tempo = clock() - tempo;
            printf("Tempo de ordenacao com Bubble Sort para %d dados foi de: %lf\n", tamanhoArray, ((double)tempo)/((CLOCKS_PER_SEC/1000)));
            break;
        case 4:
            tempo = clock();
            quickSort(array, 0, (tamanhoArray - 1));//necess�rio colocar o 0 como ponteiro inicial para chamadas recursivas com o ponteiro em novas posi��es
            tempo = clock() - tempo;
            printf("Tempo de ordenacao com Quick Sort para %d dados foi de: %lf\n", tamanhoArray, ((double)tempo)/((CLOCKS_PER_SEC/1000)));
            break;
        case 5:
            tempo = clock();
            mergeSort(array, 0, (tamanhoArray - 1));//necess�rio colocar o 0 como ponteiro inicial para chamadas recursivas com o ponteiro em novas posi��es
            tempo = clock() - tempo;
            printf("Tempo de ordenacao com Merge Sort para %d dados foi de: %lf\n", tamanhoArray, ((double)tempo)/((CLOCKS_PER_SEC/1000)));
            break;
        case 6:
            tempo = clock();
            shellSort(array, tamanhoArray);
            tempo = clock() - tempo;
            printf("Tempo de ordenacao com Shell Sort para %d dados foi de: %lf\n", tamanhoArray, ((double)tempo)/((CLOCKS_PER_SEC/1000)));
            break;
        }
}

void abreArquivo(int tam){
    switch(tam){
        case 1:
            tamanhoArray = 1000;
            dados = fopen("1000Linhas.txt","r");//abre o arquivo no modo leitura (read)
            break;
        case 2:
            tamanhoArray = 5000;
            dados = fopen("5000Linhas.txt","r");
            break;
        case 3:
            tamanhoArray = 10000;
            dados = fopen("10000Linhas.txt","r");
            break;
        case 4:
            tamanhoArray = 50000;
            dados = fopen("50000Linhas.txt","r");
            break;
        case 5:
            tamanhoArray = 100000;
            dados = fopen("100000Linhas.txt","r");
            break;
        case 6:
            tamanhoArray = 500000;
            dados = fopen("500000Linhas.txt","r");
            break;
    }
}

void validacao(void){
    if(dados == NULL){//verifica se n�o ouve erro ao abrir o arquivo
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
}

void alocacao(void){
    // Aloca��o din�mica de mem�ria para o array
    array = (int*) malloc(tamanhoArray * sizeof(int));
    if(array == NULL){
        printf("Erro ao alocar mem�ria!\n");
        return 1;
    }
}

void mostraArray(void){//utilizado para erificar se o m�todo de ordana��o relamente funcionou
    printf("-----------------------------------------\n");
    for(int a = 0; a < tamanhoArray; a++){
        printf("%d\n",array[a]);
    }
}

int main(){
    menu();
    scanf("%d", &primeiroMetodo);
    menu();
    scanf("%d", &segundoMetodo);
    menuDados();
    scanf("%d", &tamanhoBase);

    while((primeiroMetodo != 0) && (segundoMetodo != 0) && (tamanhoBase != 0)){//garante escolhas distintas para compara��o
        while(primeiroMetodo == segundoMetodo){
            primeiraOpcao = !primeiraOpcao;
            printf("ESCOLHA ENTRE DUAS OPCOES DISTINTAS\n\n");
            menu();
            scanf("%d", &segundoMetodo);
        }

        while((tamanhoBase > 6)||(tamanhoBase < 1)){//garante uma escolha dentre os valores dispon�veis
            printf("ESCOLHA ENTRE OS VALORES DISPONIVEIS\n\n");
            menuDados();
            scanf("%d", &tamanhoBase);
        }

        //chamada das fun�oes
        abreArquivo(tamanhoBase);
        alocacao();//aloca��o ocorre uma vez por loop
        validacao();
        carregarDados();
        executaMetodo(primeiroMetodo);
        //mostraArray();
        abreArquivo(tamanhoBase);
        validacao();
        carregarDados();
        executaMetodo(segundoMetodo);
        //mostraArray();

        free(array);//libera a memoria alocada
        //printf("aperte qualquer tecla para continuar");
        system("pause");//utiliza o S.O. para pausar a execu��o do programa
        printf("\e[1;1H\e[2J");//limpa tela - /e equivalente a "escape". [1;1H] coloca o cursor no canto superior direito do prompt. [2J adciona um espa�o no topo de todos os caracteres no prompt (tradu��o literal)
        menu();
        scanf("%d", &primeiroMetodo);
        menu();
        scanf("%d", &segundoMetodo);
        menuDados();
        scanf("%d", &tamanhoBase);
    }

    return 0;
}
